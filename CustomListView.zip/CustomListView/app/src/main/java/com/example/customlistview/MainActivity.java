package com.example.customlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String fruitList[]={"Apple","Banana","Apricot","Orange",
            "Water Melon"};
    int fruitImages []={ R.drawable.apple,R.drawable.banana,R.drawable.apricot,R.drawable.orange,R.drawable.watermelon};
    String abc[]={"My name is apple","my name is banana","my name is apricot","my name is orange","my name is watermelon"};
    ListView al;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        al=(ListView) findViewById(R.id.customListView);
        CustomBaseAdapter customBaseAdapter=new CustomBaseAdapter(getApplicationContext(),fruitList,fruitImages,abc);
        al.setAdapter(customBaseAdapter);

        al.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, "clicked item is " +fruitList[i], Toast.LENGTH_SHORT).show();
            }
        });

    }
}