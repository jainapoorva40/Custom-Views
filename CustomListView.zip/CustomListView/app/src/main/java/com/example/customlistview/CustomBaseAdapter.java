package com.example.customlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Constructor;

public class CustomBaseAdapter extends BaseAdapter {

    Context context;
    String listFruit[];
    int listImages[];
    String desc[];
    LayoutInflater inflater;
    public CustomBaseAdapter(Context ctx, String [] fruitList,int [] images,String [] des){

        this.context=ctx;
        this.listFruit=fruitList;
        this.listImages=images;
        this.desc=des;
        inflater=LayoutInflater.from(ctx);
    }
    @Override
    public int getCount() {
        return listFruit.length;

    }

    @Override
    public Object getItem(int i) {
        
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view=inflater.inflate(R.layout.activity_custom_list_view,null);
        TextView txtview=(TextView) view.findViewById(R.id.textView);
        ImageView fruitimg=(ImageView) view.findViewById(R.id.ImageIcon);
        TextView txtview2=(TextView) view.findViewById(R.id.abc);
        txtview.setText(listFruit[i]);
        fruitimg.setImageResource(listImages[i]);
        txtview2.setText(desc[i]);
        return view;

    }
}
